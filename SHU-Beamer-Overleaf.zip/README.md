# 上海大学 Beamer 模板 · 上大蓝

使用 XeLaTeX 编译 `slide.tex`。本地可运行 `latexmk -xelatex slide.tex`。
修改主文件中的标题、作者、日期并替换示例讲义即可开始使用。
默认画幅为 4:3，添加文档类选项 `aspectratio=169` 可切换至宽屏。

高等概率论讲义、配图及本版原创内容由 Simin 制作，适用随附的 MIT 许可证。
工程架构来自 Sheng Li 的上海大学 Beamer 模板。沿用的部分采用 CC BY 4.0。
本版更改配色、页眉、页脚与示例内容。正文页使用上海大学校徽的浅灰矢量版本。

- [GitHub 仓库](https://github.com/SiminChang/Shanghai-University-Beamer-Template)
- [Sheng Li 原模板](https://www.overleaf.com/latex/templates/shang-hai-da-xue-beamermo-ban/njsnkhjrmdns)
- [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)
- [页眉与页脚参考 · Rishit Dagli](https://www.overleaf.com/latex/templates/uoft-slide-template/xkhdjxwbwkcn)
- [上海大学校徽](https://www.shu.edu.cn/xxgk/sdwh/xhjs.htm)
